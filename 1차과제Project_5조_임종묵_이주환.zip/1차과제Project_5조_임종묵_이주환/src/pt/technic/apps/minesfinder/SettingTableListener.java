package pt.technic.apps.minesfinder;

/**
 *
 * @author Gabriel Massadas
 */
public interface SettingTableListener {
    public void settingUpdated(SettingTable setting);
}