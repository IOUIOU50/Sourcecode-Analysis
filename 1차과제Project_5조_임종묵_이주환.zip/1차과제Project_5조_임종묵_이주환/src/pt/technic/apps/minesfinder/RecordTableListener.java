package pt.technic.apps.minesfinder;

/**
 *
 * @author Gabriel Massadas
 */
public interface RecordTableListener {
    public void recordUpdated(RecordTable record);
}
