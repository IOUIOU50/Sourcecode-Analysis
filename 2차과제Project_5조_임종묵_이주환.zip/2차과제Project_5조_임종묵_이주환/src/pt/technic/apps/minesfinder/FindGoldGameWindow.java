package pt.technic.apps.minesfinder;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class FindGoldGameWindow extends SpecialGameWindow {

	private FindGoldMinefield findGoldMinefield;

	public FindGoldGameWindow() {
		initComponents();
	}

	public FindGoldGameWindow(FindGoldMinefield findGoldField, SettingTable setting) {
		this.minefield = findGoldField;
		this.findGoldMinefield = findGoldField;
		this.setting = setting;

		initComponents();

		buttons = new ButtonMinefield[findGoldField.getWidth()][findGoldField.getHeight()];

		getContentPane().setLayout(new GridLayout(findGoldField.getWidth(), findGoldField.getHeight()));

		addActionListener();
		addMouseListener();
		addKeyListener();

		createButtons();
	}

	@Override
	protected void addActionListener() {
		this.action = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ButtonMinefield button = (ButtonMinefield) e.getSource();
				int x = button.getCol();
				int y = button.getLine();
				findGoldMinefield.revealGrid(x, y);
				updateButtonsStates();
				if (findGoldMinefield.isGameFinished()) {
					if (findGoldMinefield.isPlayerDefeated()) {
						result = JOptionPane.showConfirmDialog(null, "Play the game again?", "Defeated!",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							findGoldMinefield.retryGame();
							updateButtonsStates();
						} else {
							setVisible(false);
						}
					} else {
						JOptionPane.showMessageDialog(null,
								"Congratulations. You managed to discover all the mines"
										,"victory", JOptionPane.INFORMATION_MESSAGE);
						setVisible(false);
					}
				}
			}
		};
	}
}
