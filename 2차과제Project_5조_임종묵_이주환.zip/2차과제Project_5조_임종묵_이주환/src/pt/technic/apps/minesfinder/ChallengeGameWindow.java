package pt.technic.apps.minesfinder;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ChallengeGameWindow extends SpecialGameWindow {
	private ChallengeMinefield challengeMinefield;

	private JPanel buttonMinePanel;
	private JPanel itemPanel;
	private JButton btnClearCount;

	public ChallengeGameWindow() {
		initComponents();
	}

	public ChallengeGameWindow(ChallengeMinefield challengeMinefield, SettingTable setting) {
		this.challengeMinefield = challengeMinefield;
		this.minefield = challengeMinefield;
		this.setting = setting;
		buttonMinePanel = new JPanel(new GridLayout(challengeMinefield.getWidth(), challengeMinefield.getHeight()));
		itemPanel = new JPanel();

		btnClearCount = new JButton("ClearCount : " + challengeMinefield.getClearCount());
		btnClearCount.setEnabled(false);

		itemPanel.add(btnClearCount);
		initComponents();

		buttons = new ButtonMinefield[challengeMinefield.getWidth()][challengeMinefield.getHeight()];

		getContentPane().setLayout(new BorderLayout());

		addActionListener();
		addMouseListener();
		addKeyListener();

		createButtons();
		getContentPane().add(buttonMinePanel);
		getContentPane().add(itemPanel, BorderLayout.NORTH);
	}

	@Override
	protected void addActionListener() {
		// TODO Auto-generated method stub
		this.action = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				ButtonMinefield button = (ButtonMinefield) e.getSource();
				int x = button.getCol();
				int y = button.getLine();

				challengeMinefield.revealGrid(x, y);
				updateButtonsStates();

				if (challengeMinefield.isGameFinished()) {
					if (challengeMinefield.isPlayerDefeated()) {
						result = JOptionPane.showConfirmDialog(null, "Play the game again?", "Defeated!",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							challengeMinefield.retryGame();
							updateButtonsStates();
							btnClearCount.setText("ClearCount : " + challengeMinefield.getClearCount());
						} else {
							setVisible(false);
						}
					} else {
						result = JOptionPane.showConfirmDialog(null, "Continue the game?", "Cleared!",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							challengeMinefield.cleared();
							challengeMinefield.retryGame();
							updateButtonsStates();
							btnClearCount.setText("ClearCount : " + challengeMinefield.getClearCount());
						} else {
							setVisible(false);
						}
					}
				}

			}
		};
	}

	@Override
	protected void updateButtonsStates() {
		for (int x = 0; x < challengeMinefield.getWidth(); x++) {
			for (int y = 0; y < challengeMinefield.getHeight(); y++) {
				buttons[x][y].setEstado(challengeMinefield.getGridState(x, y));
			}
		}
	}

	@Override
	protected void createButtons() {
		for (int x = 0; x < challengeMinefield.getWidth(); x++) {
			for (int y = 0; y < challengeMinefield.getHeight(); y++) {
				buttons[x][y] = new ButtonMinefield(x, y);
				buttons[x][y].addActionListener(action);
				buttons[x][y].addMouseListener(mouseListener);
				buttons[x][y].addKeyListener(keyListener);
				buttonMinePanel.add(buttons[x][y]);
			}
		}
	}
}
