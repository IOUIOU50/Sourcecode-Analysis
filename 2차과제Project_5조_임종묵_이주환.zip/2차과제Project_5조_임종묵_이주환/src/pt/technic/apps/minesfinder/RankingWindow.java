package pt.technic.apps.minesfinder;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextField;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class RankingWindow extends javax.swing.JFrame {
	public RankingWindow(RecordTable recordEasy, RecordTable recordMedium, RecordTable recordHard) {   
	      
	      setTitle("Ranking");
	      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	      
	      Container rankWindow = getContentPane();
	      
	      rankWindow.setLayout(new FlowLayout());
	      rankWindow.add(rank(recordEasy));
	      rankWindow.add(rank(recordMedium));
	      rankWindow.add(rank(recordHard));
	      
	      setSize(700,300);
	      
	   }
	   
	   private JPanel rank(RecordTable record) {
	      JPanel rank = new JPanel();
	      rank.setLayout(new GridLayout(10,2));
	      
	      for(int i=0; i<10; i++) {
	         rank.add(new TextField(record.getName(i)));
	         rank.add(new TextField(Long.toString(record.getScore(i)/1000)));
	      }
	      
	      return rank;   
	   }
}
