package pt.technic.apps.minesfinder;

import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Random;

import javax.swing.*;

public class ItemGameWindow extends SpecialGameWindow {

	private ItemMinefield itemMinefield;
	private JPanel buttonPanel;
	private JPanel itemPanel;
	private JButton btnMineDetector;
	private JButton btnLife;

	private HashMap<Integer, Integer> mineList;

	public ItemGameWindow() {
		initComponents();
	}

	public ItemGameWindow(ItemMinefield itemMinefield, SettingTable setting) {
		this.minefield = itemMinefield;
		this.itemMinefield = itemMinefield;
		this.setting = setting;

		buttonPanel = new JPanel(new GridLayout(itemMinefield.getWidth(), itemMinefield.getHeight()));
		itemPanel = new JPanel();
		btnMineDetector = new JButton("MineDetector : " + Integer.toString(itemMinefield.getItem()));
		btnLife = new JButton("Life : " + itemMinefield.getLife());
		btnLife.setEnabled(false);

		mineList = new HashMap<Integer, Integer>();

		btnMineDetector.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				if (itemMinefield.getItem() <= 0) {
					JOptionPane.showMessageDialog(getContentPane(), "You have no Mine Detector!");
					return;
				} else {
					for (int i = 0; i < itemMinefield.getWidth(); i++) {
						for (int j = 0; j < itemMinefield.getHeight(); j++) {
							if (itemMinefield.hasMine(i, j)) {
								mineList.put(i, j);
							}
						}
					}
					Random random = new Random();
					int x = -1;
					int y = -1;
					int tmp;
					while (!mineList.isEmpty()) {
						tmp = random.nextInt(16);
						if (mineList.containsKey(tmp)) {
							x = tmp;
							y = mineList.get(x);
							break;
						}
					}
					if (x >= 0 && y >= 0) {
						itemMinefield.useItem();
						itemMinefield.setMineMarked(x, y);
						updateButtonsStates();
					}
				}
				btnMineDetector.setText("MineDetector : " + Integer.toString(itemMinefield.getItem()));
				if (itemMinefield.getItem() <= 0)
					btnMineDetector.setEnabled(false);
			}
		});

		itemPanel.add(btnLife);
		itemPanel.add(btnMineDetector);
		initComponents();

		buttons = new ButtonMinefield[itemMinefield.getWidth()][itemMinefield.getHeight()];

		getContentPane().setLayout(new BorderLayout());

		addActionListener();
		addMouseListener();
		addKeyListener();

		createButtons();

		getContentPane().add(buttonPanel);
		getContentPane().add(itemPanel, BorderLayout.NORTH);
	}

	@Override
	protected void addActionListener() {
		// TODO Auto-generated method stub
		this.action = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ButtonMinefield button = (ButtonMinefield) e.getSource();
				int x = button.getCol();
				int y = button.getLine();

				itemMinefield.revealGrid(x, y);
				updateButtonsStates();

				if (itemMinefield.hasMine(x, y) && itemMinefield.getLife() >= 0) {
					JOptionPane.showMessageDialog(null,
							"Be careful! now you have " + itemMinefield.getLife() + " Life.");
					buttons[x][y].setEstado(itemMinefield.MARKED);

					btnLife.setText("Life : " + itemMinefield.getLife());
					btnMineDetector.setText("MineDetector : " + Integer.toString(itemMinefield.getItem()));
				}

				else if (itemMinefield.isGameFinished()) {
					if (itemMinefield.isPlayerDefeated()) {
						result = JOptionPane.showConfirmDialog(null, "Play the game again?", "Defeated!",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							itemMinefield.retryGame();
							btnMineDetector.setEnabled(true);
							updateButtonsStates();
							btnLife.setText("Life : " + itemMinefield.getLife());
							btnMineDetector.setText("MineDetector : " + Integer.toString(itemMinefield.getItem()));
						} else {
							setVisible(false);
						}
					} else {
						JOptionPane.showMessageDialog(null,
								"Congratulations. You managed to discover all the mines"
										,"victory", JOptionPane.INFORMATION_MESSAGE);
						setVisible(false);
					}
				}
			}
		};
	}

	@Override
	protected void updateButtonsStates() {
		for (int x = 0; x < itemMinefield.getWidth(); x++) {
			for (int y = 0; y < itemMinefield.getHeight(); y++) {
				buttons[x][y].setEstado(itemMinefield.getGridState(x, y));
			}
		}
	}

	@Override
	protected void createButtons() {
		for (int x = 0; x < itemMinefield.getWidth(); x++) {
			for (int y = 0; y < itemMinefield.getHeight(); y++) {
				buttons[x][y] = new ButtonMinefield(x, y);
				buttons[x][y].addActionListener(action);
				buttons[x][y].addMouseListener(mouseListener);
				buttons[x][y].addKeyListener(keyListener);
				buttonPanel.add(buttons[x][y]);
			}
		}
	}
}
