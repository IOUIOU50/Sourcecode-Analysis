package pt.technic.apps.minesfinder;

public class FindGoldMinefield extends Minefield {
	public static final int FINDGOLD = 13;

	protected boolean[][] golds;
	protected int numGolds;
	protected int countGold;

	public FindGoldMinefield(int width, int height, int numMines, int numGolds) {
		super(width, height, numMines);
		this.numGolds = numGolds;
		golds = new boolean[width][height];
	}

	public void revealGrid(int x, int y) {
		if (states[x][y] == COVERED && !gameFinished) {
			if (firstPlay) {
				firstPlay = false;
				placeMines(x, y);
				placeGolds(x, y);
			}

			if (mines[x][y]) {
				states[x][y] = BUSTED;
				playerDefeated = true;
				gameFinished = true;
				return;
			}

			if (golds[x][y]) {
				states[x][y] = FINDGOLD;
				this.countGold++;
				if (checkVictory()) {
					gameFinished = true;
					playerDefeated = false;
					return;
				}
				return;
			}

			int minesAround = countMinesAround(x, y);
			int goldsAround = countGoldsAround(x, y);
			states[x][y] = minesAround;

			if (minesAround == 0 && goldsAround == 0) {
				revealGridNeighbors(x, y);
			}
		}
	}

	protected boolean checkVictory() {
		boolean victory = false;
		if (this.countGold == this.numGolds)
			victory = true;
		return victory;
	}

	private int countGoldsAround(int x, int y) {
		int result = 0;
		for (int col = Math.max(0, x - 1); col < Math.min(width, x + 2); col++) {
			for (int line = Math.max(0, y - 1); line < Math.min(height, y + 2); line++) {
				if (golds[col][line]) {
					result++;
				}
			}
		}
		return result - (golds[x][y] ? 1 : 0);
	}

	private void placeGolds(int plX, int plY) {
		for (int i = 0; i < numGolds; i++) {
			int x = 0;
			int y = 0;
			do {
				x = random.nextInt(width);
				y = random.nextInt(height);
			} while (golds[x][y] || (x == plX && y == plY) || mines[x][y]);
			golds[x][y] = true;
		}

	}

	public void retryGame() {
		firstPlay = true;
		playerDefeated = false;
		gameFinished = false;
		this.countGold = 0;

		setButtonStateCovered();
		mines = new boolean[width][height];
		golds = new boolean[width][height];
		timeGameStarted = System.currentTimeMillis();
	}
}
