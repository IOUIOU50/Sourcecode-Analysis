package pt.technic.apps.minesfinder;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

import javax.swing.JOptionPane;

public class SpecialGameWindow extends GameWindow {

	public SpecialGameWindow() {
	}

	public SpecialGameWindow(Minefield minefield, SettingTable setting) {
		this.minefield = minefield;
		this.setting = setting;

		initComponents();

		buttons = new ButtonMinefield[minefield.getWidth()][minefield.getHeight()];

		getContentPane().setLayout(new GridLayout(minefield.getWidth(), minefield.getHeight()));

		addActionListener();
		addMouseListener();
		addKeyListener();

		createButtons();
	}

	@Override
	protected void addActionListener() {
		// TODO Auto-generated method stub
		this.action = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ButtonMinefield button = (ButtonMinefield) e.getSource();
				int x = button.getCol();
				int y = button.getLine();
				minefield.revealGrid(x, y);
				updateButtonsStates();
				if (minefield.isGameFinished()) {
					if (minefield.isPlayerDefeated()) {
						result = JOptionPane.showConfirmDialog(null, "Play the game again?", "Defeated!",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							minefield.retryGame();
							updateButtonsStates();
						} else {
							setVisible(false);
						}
					} else {
						JOptionPane.showMessageDialog(null,
								"Congratulations. You managed to discover all the mines"
										,"victory", JOptionPane.INFORMATION_MESSAGE);
						setVisible(false);
					}
				}
			}
		};
	}

	@Override
	protected void addMouseListener() {
		// TODO Auto-generated method stub
		this.mouseListener = new MouseListener() {
			@Override
			public void mousePressed(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub
				if (e.getButton() == java.awt.event.MouseEvent.BUTTON3) {
					ButtonMinefield botao = (ButtonMinefield) e.getSource();
					int x = botao.getCol();
					int y = botao.getLine();
					if (minefield.getGridState(x, y) == minefield.COVERED) {
						minefield.setMineMarked(x, y);
					} else if (minefield.getGridState(x, y) == minefield.MARKED) {
						minefield.setMineQuestion(x, y);
					} else if (minefield.getGridState(x, y) == minefield.QUESTION) {
						minefield.setMineCovered(x, y);
					}
					updateButtonsStates();
				}
			}

			@Override
			public void mouseReleased(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void mouseExited(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void mouseEntered(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			public void mouseClicked(java.awt.event.MouseEvent e) {
				// TODO Auto-generated method stub
			}
		};
	}

	@Override
	protected void addKeyListener() {
		// TODO Auto-generated method stub
		this.keyListener = new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				ButtonMinefield botao = (ButtonMinefield) e.getSource();
				int x = botao.getWidth();
				int y = botao.getHeight();
				if (e.getKeyCode() == KeyEvent.VK_UP && y > 0) {
					buttons[x][y - 1].requestFocus();
				} else if (e.getKeyCode() == KeyEvent.VK_LEFT && x > 0) {
					buttons[x - 1][y].requestFocus();
				} else if (e.getKeyCode() == KeyEvent.VK_DOWN && y < minefield.getHeight() - 1) {
					buttons[x][y + 1].requestFocus();
				} else if (e.getKeyCode() == KeyEvent.VK_RIGHT && x < minefield.getWidth() - 1) {
					buttons[x + 1][y].requestFocus();
				} else if (e.getKeyCode() == KeyEvent.VK_M) {
					if (minefield.getGridState(x, y) == minefield.COVERED) {
						minefield.setMineMarked(x, y);
					} else if (minefield.getGridState(x, y) == minefield.MARKED) {
						minefield.setMineQuestion(x, y);
					} else if (minefield.getGridState(x, y) == minefield.QUESTION) {
						minefield.setMineCovered(x, y);
					}
					updateButtonsStates();
				}
			}
		};
	}
}
