package pt.technic.apps.minesfinder;

public class ChallengeMinefield extends Minefield {
	protected int clearCount;
	protected boolean isCleared;

	public ChallengeMinefield(int width, int height, int numMines) {
		super(width, height, numMines);
		clearCount = 0;
		isCleared = false;
	}

	public void revealGrid(int x, int y) {
		if (states[x][y] == COVERED && !gameFinished) {
			if (firstPlay) {
				firstPlay = false;
				placeMines(x, y);
			}

			if (mines[x][y]) {
				states[x][y] = MARKED;
				for (int i = 0; i < width; i++) {
					for (int j = 0; j < height; j++) {
						if (mines[i][j])
							states[i][j] = BUSTED;
					}
				}

				playerDefeated = true;
				gameFinished = true;
				return;
			} else {
				int minesAround = countMinesAround(x, y);
				states[x][y] = minesAround;

				if (minesAround == 0) {
					revealGridNeighbors(x, y);
				}

				if (checkVictory()) {
					gameFinished = true;
					playerDefeated = false;
					return;
				}
			}
		}

	}

	public void retryGame() {
		firstPlay = true;
		playerDefeated = false;
		gameFinished = false;

		setButtonStateCovered();
		mines = new boolean[width][height];
		if (isCleared) {
			clearCount++;
			isCleared = false;
			return;
		}
		clearCount = 0;
	}

	public void cleared() {
		this.isCleared = true;
	}

	public int getClearCount() {
		return clearCount;
	}
}
