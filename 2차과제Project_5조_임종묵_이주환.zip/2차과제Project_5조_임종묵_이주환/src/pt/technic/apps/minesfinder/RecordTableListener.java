package pt.technic.apps.minesfinder;

public interface RecordTableListener {
	public void recordUpdated(RecordTable record);
}
