package pt.technic.apps.minesfinder;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JOptionPane;

public class NormalGameWindow extends GameWindow {

	protected RecordTable record;
	
	public NormalGameWindow() {
		initComponents();
	}
	
	public NormalGameWindow(Minefield minefield, RecordTable record, SettingTable setting) {
		this.minefield = minefield;
		this.record = record;
		this.setting = setting;

		initComponents();

		buttons = new ButtonMinefield[minefield.getWidth()][minefield.getHeight()];

		getContentPane().setLayout(new GridLayout(minefield.getWidth(), minefield.getHeight()));

		addActionListener();
		addMouseListener();
		addKeyListener();

		createButtons();
	}

	@Override
	protected void addActionListener() {
		// TODO Auto-generated method stub
		this.action = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ButtonMinefield button = (ButtonMinefield) e.getSource();
				int x = button.getCol();
				int y = button.getLine();
				minefield.revealGrid(x, y);
				updateButtonsStates();
				if (minefield.isGameFinished()) {
					if (minefield.isPlayerDefeated()) {
						result = JOptionPane.showConfirmDialog(null, "Play the game again?", "Defeated!",
								JOptionPane.YES_NO_OPTION);
						if (result == 0) {
							minefield.retryGame();
							updateButtonsStates();
						} else {
							setVisible(false);
						}
					} else {
						JOptionPane.showMessageDialog(null,
								"Congratulations. You managed to discover all the mines in "
										+ (minefield.getGameDuration() / 1000) + " seconds",
								"victory", JOptionPane.INFORMATION_MESSAGE);
						String name = JOptionPane.showInputDialog("Enter your name");
						if (name != "")
							record.setRecord(name, minefield.getGameDuration());

						setVisible(false);
					}
				}
			}
		};
	}

	@Override
	protected void addMouseListener() {
		this.mouseListener = new MouseListener() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON3) {
					ButtonMinefield botao = (ButtonMinefield) e.getSource();
					int x = botao.getCol();
					int y = botao.getLine();
					if (minefield.getGridState(x, y) == minefield.COVERED) {
						minefield.setMineMarked(x, y);
					} else if (minefield.getGridState(x, y) == minefield.MARKED) {
						minefield.setMineQuestion(x, y);
					} else if (minefield.getGridState(x, y) == minefield.QUESTION) {
						minefield.setMineCovered(x, y);
					}
					updateButtonsStates();
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		};
		// TODO Auto-generated method stub
	}

	@Override
	protected void addKeyListener() {
		// TODO Auto-generated method stub
	}
}
