package pt.technic.apps.minesfinder;

public class ItemMinefield extends Minefield {

	protected int mineDetector;
	protected int life;

	public ItemMinefield(int width, int height, int numMines) {
		super(width, height, numMines);
		mineDetector = 3;
		life = 3;
	}

	public void revealGrid(int x, int y) {
		if (states[x][y] == COVERED && !gameFinished) {
			if (firstPlay) {
				firstPlay = false;
				placeMines(x, y);
			}

			if (mines[x][y]) {
				states[x][y] = MARKED;
				life--;
				if (life < 0) {
					for (int i = 0; i < width; i++) {
						for (int j = 0; j < height; j++) {
							if (mines[i][j])
								states[i][j] = BUSTED;
						}
					}

					playerDefeated = true;
					gameFinished = true;
					return;
				}
			} else {
				int minesAround = countMinesAround(x, y);
				states[x][y] = minesAround;

				if (minesAround == 0) {
					revealGridNeighbors(x, y);
				}

				if (checkVictory()) {
					gameFinished = true;
					playerDefeated = false;
					return;
				}
			}
		}

	}

	public void retryGame() {
		playerDefeated = false;
		gameFinished = false;

		setButtonStateCovered();
		mines = new boolean[width][height];
		mineDetector = 3;
		life = 3;
	}

	public void useItem() {
		this.mineDetector--;
	}

	public int getItem() {
		return mineDetector;
	}

	public int getLife() {
		return life;
	}

}
