package pt.technic.apps.minesfinder;

import java.io.Serializable;

public class SettingTable implements Serializable {

	private int menuWidth;
	private int menuHeight;
	private int inGameWidth;
	private int inGameHeight;
	private boolean playSound;

	public SettingTable() {
		menuWidth = 600;
		menuHeight = 450;
		inGameWidth = 800;
		inGameHeight = 600;
		playSound = true;
	}

	public int getMenuWidth() {
		return menuWidth;
	}

	public int getMenuHeight() {
		return menuHeight;
	}

	public int getInGameWidth() {
		return inGameWidth;
	}

	public int getInGameHeight() {
		return inGameHeight;
	}

	public void setMenuWidthHeight(int menuWidth, int menuHeight) {
		this.menuWidth = menuWidth;
		this.menuHeight = menuHeight;
	}

	public void setInGameWidthHeight(int inGameWidth, int inGameHeight) {
		this.inGameWidth = inGameWidth;
		this.inGameHeight = inGameHeight;
	}

	public boolean getPlaySound() {
		return playSound;
	}

	public void setPlaySound(boolean playSound) {
		this.playSound = playSound;
	}
}