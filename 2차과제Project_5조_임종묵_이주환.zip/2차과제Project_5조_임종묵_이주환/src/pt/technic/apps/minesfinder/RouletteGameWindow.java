package pt.technic.apps.minesfinder;

import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JOptionPane;

public class RouletteGameWindow extends SpecialGameWindow {
	public static final int buttonIndex = 49; // ASCII CODE. Equals integer '0'

	private int mineCount;

	public RouletteGameWindow() {
		initComponents();
	}

	public RouletteGameWindow(Minefield minefield, SettingTable setting) {
		this.setting = setting;
		this.minefield = minefield;

		mineCount = minefield.getNumMines();

		initComponents();

		buttons = new ButtonMinefield[minefield.getWidth()][minefield.getHeight()];

		getContentPane().setLayout(new GridLayout(minefield.getWidth(), minefield.getHeight()));

		minefield.placeMines(minefield.getWidth(), minefield.getHeight());

		addKeyListener();
		createButtons();
	}

	@Override
	protected void addKeyListener() {
		// TODO Auto-generated method stub
		this.keyListener = new KeyListener() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (minefield.hasMine(0, (int) e.getKeyCode() - 49)) {
					buttons[0][(int) e.getKeyCode() - buttonIndex].setEstado(minefield.BUSTED);
					mineCount--;
					if (mineCount <= 0) {
						JOptionPane.showMessageDialog(getContentPane(), "If you confirmed, Click 'OK'",
								e.getKeyCode() - buttonIndex + 1 + "Person is selected!",
								JOptionPane.INFORMATION_MESSAGE);
						setVisible(false);

					}
				} else
					buttons[0][(int) e.getKeyCode() - buttonIndex].setEstado(minefield.EMPTY);
			}

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		};
	}

	@Override
	protected void createButtons() {
		for (int x = 0; x < minefield.getWidth(); x++) {
			for (int y = 0; y < minefield.getHeight(); y++) {
				buttons[x][y] = new ButtonMinefield(x, y);
				buttons[x][y].setText(Integer.toString(y + 1));
				buttons[x][y].addKeyListener(keyListener);
				getContentPane().add(buttons[x][y]);
			}
		}
	}
}
