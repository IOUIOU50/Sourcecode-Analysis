
package pt.technic.apps.minesfinder;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class NormalMode extends javax.swing.JFrame {

	private javax.swing.JLabel Records;
	private javax.swing.JButton btnEasy;
	private javax.swing.JButton btnExit;
	private javax.swing.JButton btnHard;
	private javax.swing.JButton btnMedium;
	private javax.swing.JLabel labelEasy;
	private javax.swing.JLabel labelEasyName;
	private javax.swing.JLabel labelEasyPoints;
	private javax.swing.JLabel labelHard;
	private javax.swing.JLabel labelHardName;
	private javax.swing.JLabel labelHardPoints;
	private javax.swing.JLabel labelMedium;
	private javax.swing.JLabel labelMediumName;
	private javax.swing.JLabel labelMediumPoints;
	private javax.swing.JPanel panelEasy;
	private javax.swing.JPanel panelHard;
	private javax.swing.JPanel panelMedium;
	private javax.swing.JPanel panelBtns;
	private javax.swing.JPanel panelRecords;
	private javax.swing.JLabel panelTitle;

	private RecordTable recordEasy;
	private RecordTable recordMedium;
	private RecordTable recordHard;
	private SettingTable setting;

	public NormalMode() {
		initComponents();
	}

	public NormalMode(RecordTable recordEasy, RecordTable recordMedium, RecordTable recordHard, SettingTable setting) {
		this.recordEasy = recordEasy;
		this.recordMedium = recordMedium;
		this.recordHard = recordHard;
		this.setting = setting;
		initComponents();

		labelEasyName.setText(recordEasy.getName(0));
		labelEasyPoints.setText(Long.toString(recordEasy.getScore(0) / 1000));
		labelMediumName.setText(recordMedium.getName(0));
		labelMediumPoints.setText(Long.toString(recordMedium.getScore(0) / 1000));
		labelHardName.setText(recordHard.getName(0));
		labelHardPoints.setText(Long.toString(recordHard.getScore(0) / 1000));

		recordEasy.addRecordTableListener(new RecordTableListener() {
			@Override
			public void recordUpdated(RecordTable record) {
				recordEasyUpdated(record);
			}
		});

		recordMedium.addRecordTableListener(new RecordTableListener() {
			@Override
			public void recordUpdated(RecordTable record) {
				recordMediumUpdated(record);
			}
		});

		recordHard.addRecordTableListener(new RecordTableListener() {
			@Override
			public void recordUpdated(RecordTable record) {
				recordHardUpdated(record);
			}
		});
	}

	private void recordEasyUpdated(RecordTable record) {
		labelEasyName.setText(record.getName(0));
		labelEasyPoints.setText(Long.toString(record.getScore(0) / 1000));
		saveGameRecords();
	}

	private void recordMediumUpdated(RecordTable record) {
		labelMediumName.setText(record.getName(0));
		labelMediumPoints.setText(Long.toString(record.getScore(0) / 1000));
		saveGameRecords();
	}

	private void recordHardUpdated(RecordTable record) {
		labelHardName.setText(record.getName(0));
		labelHardPoints.setText(Long.toString(record.getScore(0) / 1000));
		saveGameRecords();
	}

	private void saveGameRecords() {
		ObjectOutputStream oos = null;
		try {
			File f = new File(System.getProperty("user.home") + File.separator + ".minesfinder.records");
			oos = new ObjectOutputStream(new FileOutputStream(f));
			oos.writeObject(recordEasy);
			oos.writeObject(recordMedium);
			oos.writeObject(recordHard);
			oos.close();
		} catch (IOException ex) {
			Logger.getLogger(NormalMode.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	private void btnEasyActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnEasyActionPerformed
		NormalGameWindow easyGameWindow = new NormalGameWindow(new Minefield(9, 9, 10), recordEasy, setting);
		easyGameWindow.setVisible(true);
	}

	private void btnMediumActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnMediumActionPerformed
		NormalGameWindow mediumGameWindow = new NormalGameWindow(new Minefield(16, 16, 40), recordMedium, setting);
		mediumGameWindow.setVisible(true);
	}

	private void btnHardActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnHardActionPerformed
		NormalGameWindow hardGameWindow = new NormalGameWindow(new Minefield(16, 30, 90), recordHard, setting);
		hardGameWindow.setVisible(true);
	}

	private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnExitActionPerformed
		this.setVisible(false);
	}

	private void initComponents() {
		panelTitle = new javax.swing.JLabel();
		panelRecords = new javax.swing.JPanel();
		Records = new javax.swing.JLabel();
		labelEasy = new javax.swing.JLabel();
		panelEasy = new javax.swing.JPanel();
		labelEasyName = new javax.swing.JLabel();
		labelEasyPoints = new javax.swing.JLabel();
		labelMedium = new javax.swing.JLabel();
		labelMediumName = new javax.swing.JLabel();
		labelMediumPoints = new javax.swing.JLabel();
		labelHard = new javax.swing.JLabel();
		labelHardName = new javax.swing.JLabel();
		labelHardPoints = new javax.swing.JLabel();
		panelEasy = new javax.swing.JPanel();
		panelMedium = new javax.swing.JPanel();
		panelHard = new javax.swing.JPanel();
		panelBtns = new javax.swing.JPanel();
		btnEasy = new javax.swing.JButton();
		btnMedium = new javax.swing.JButton();
		btnHard = new javax.swing.JButton();
		btnExit = new javax.swing.JButton(); // *exit

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("MinesFinder");
		setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
		setPreferredSize(new java.awt.Dimension(setting.getMenuWidth(), setting.getMenuHeight()));
		setResizable(false);
		setLayout(new BorderLayout());

		panelTitle.setBackground(new java.awt.Color(136, 135, 217));
		panelTitle.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
		panelTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		panelTitle.setText("Minesfinder");
		panelTitle.setOpaque(true);
		getContentPane().add(panelTitle, BorderLayout.PAGE_START);

		panelRecords.setBackground(new java.awt.Color(118, 206, 108));
		panelRecords.setLayout(new GridLayout(7, 1));

		Records.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
		Records.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Records.setText("Records");

		initRecords(panelEasy, labelEasy, labelEasyName, labelEasyPoints);
		initRecords(panelMedium, labelMedium, labelMediumName, labelMediumPoints);
		initRecords(panelHard, labelHard, labelHardName, labelHardPoints);
		labelEasy.setText("Easy");
		labelMedium.setText("Medium");
		labelHard.setText("Hard");

		panelRecords.add(Records);
		panelRecords.add(labelEasy);
		panelRecords.add(panelEasy);
		panelRecords.add(labelMedium);
		panelRecords.add(panelMedium);
		panelRecords.add(labelHard);
		panelRecords.add(panelHard);

		getContentPane().add(panelRecords, BorderLayout.WEST);

		initBtns();

		pack();
	}

	private void initBtns() {
		panelBtns.setLayout(new java.awt.GridLayout(2, 0));

		btnEasy.setIcon(
				new javax.swing.ImageIcon(getClass().getResource("/pt/technic/apps/minesfinder/resources/easy.png"))); // NOI18N
		btnEasy.setText("Easy");
		btnEasy.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnEasyActionPerformed(evt);
			}
		});
		panelBtns.add(btnEasy);

		btnMedium.setIcon(
				new javax.swing.ImageIcon(getClass().getResource("/pt/technic/apps/minesfinder/resources/medium.png"))); // NOI18N
		btnMedium.setText("Medium");
		btnMedium.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnMediumActionPerformed(evt);
			}
		});
		panelBtns.add(btnMedium);

		btnHard.setIcon(
				new javax.swing.ImageIcon(getClass().getResource("/pt/technic/apps/minesfinder/resources/hard.png"))); // NOI18N
		btnHard.setText("Hard");
		btnHard.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnHardActionPerformed(evt);
			}
		});
		panelBtns.add(btnHard);

		btnExit.setText("Exit");
		btnExit.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnExitActionPerformed(evt);
			}
		});
		panelBtns.add(btnExit);

		getContentPane().add(panelBtns, java.awt.BorderLayout.CENTER);
	}

	private void initRecords(JPanel panelDifficulty, JLabel labelDifficulty, JLabel labelName, JLabel labelPoints) {
		labelDifficulty.setFont(new java.awt.Font("Noto Sans", 0, 14)); // NOI18N
		labelDifficulty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		labelName.setText("Player");
		labelPoints.setText("9999");
		panelDifficulty.add(labelName);
		panelDifficulty.add(labelPoints);
		panelDifficulty.setBackground(new java.awt.Color(118, 206, 108));
	}
}
